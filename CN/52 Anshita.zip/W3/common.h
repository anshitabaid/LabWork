#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include<sys/ioctl.h>
#include<string.h>
#include<sys/time.h>
#define PORT 8400
#define MY_IP_ADDR "172.16.58.150"
#define BUFLEN 256
